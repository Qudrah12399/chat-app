
# Aplikasi Pesan v1.6

Aplikasi pesan berbasis HTML, CSS, dan JavaScript tanpa backend.

## 🔧 Fitur Utama
- 📞 Simulasi panggilan suara/video (UI dummy)
- 🔒 Enkripsi & dekripsi pesan (Base64)
- 🎨 Tema kustom
- 🖼️ Kirim gambar
- 🗂️ Filter pengguna/grup
- 📤 Auto-scroll dan notifikasi pesan baru

## 🚀 Cara Menjalankan
1. Ekstrak file ZIP
2. Buka file `chat-app-v1.6.html` di browser

## 🌐 Hosting (Opsional)
### 1. GitHub Pages
- Upload file ke repository publik dan rename jadi `index.html`
- Aktifkan GitHub Pages dari menu Settings

### 2. Netlify
- Kunjungi [netlify.com](https://www.netlify.com/)
- Login dan drag & drop file HTML ke dashboard
- Link publik akan langsung tersedia

---

Made with ❤️ in ChatGPT
